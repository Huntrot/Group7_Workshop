package org.example.flyora_backend.service;

import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

import org.example.flyora_backend.DTOs.ProductBestSellerDTO;
import org.example.flyora_backend.DTOs.ProductDetailDTO;
import org.example.flyora_backend.DTOs.ProductFilterDTO;
import org.example.flyora_backend.DTOs.ProductListDTO;
import org.example.flyora_backend.dynamo.models.ProductCategoryDynamoDB;
import org.example.flyora_backend.dynamo.models.ProductDynamoDB;
import org.example.flyora_backend.repository.ProductCategoryRepository;
import org.example.flyora_backend.repository.ProductRepository;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ProductCategoryRepository categoryRepository; // Inject thêm để lấy tên category

    @Override
    public List<ProductListDTO> filterProducts(ProductFilterDTO filter) {
        return productRepository.filterProducts(
                filter.getName(),
                filter.getCategoryId(),
                filter.getBirdTypeId(),
                filter.getMinPrice(),
                filter.getMaxPrice());
    }

    @Override
    public List<ProductBestSellerDTO> getTop15BestSellers() {
        return productRepository.findTop15BestSellers();
    }

    @Override
    public List<ProductListDTO> searchByName(String name) {
        return productRepository.searchByName(name);
    }

    @Override
    public List<ProductListDTO> getProductByStatus() {
        // SỬA LỖI: Filter thủ công bằng Java Stream thay vì gọi hàm repo
        return productRepository.findAll().stream()
                .filter(p -> p.getStatus() == 1) // Chỉ lấy sản phẩm active
                .map(this::mapToDTO) // Hàm helper bên dưới
                .collect(Collectors.toList());
    }

    @Override
    public ProductDynamoDB addProduct(ProductDynamoDB product) {
        // SỬA LỖI: Bỏ Adapter, dùng trực tiếp DynamoDB
        productRepository.save(product);
        return product;
    }

    @Override
    public ProductDetailDTO getProductDetail(Integer id) {
        // SỬA LỖI: Optional handling
        ProductDynamoDB d = productRepository.findById(id)
             .orElseThrow(() -> new RuntimeException("Product not found"));

        // Manual lookup category name
        String catName = categoryRepository.findById(d.getCategoryId())
                .map(ProductCategoryDynamoDB::getName).orElse("Unknown");

        return new ProductDetailDTO(
                d.getId(),
                d.getName(),
                d.getDescription(),
                d.getPrice(),
                d.getStock(),
                catName,
                "Unknown", // BirdType name cần lookup tương tự nếu cần
                null // ImageURL cần logic lấy từ DetailRepo nếu cần
        );
    }

    @Override
    public Integer deleteProductById(int id) {
        // SỬA LỖI: Tên hàm chuẩn là deleteById
        productRepository.deleteById(id);
        return 1;
    }
    
    // Helper
    private ProductListDTO mapToDTO(ProductDynamoDB p) {
        ProductListDTO dto = new ProductListDTO();
        dto.setId(p.getId());
        dto.setName(p.getName());
        dto.setPrice(p.getPrice());
        dto.setStock(p.getStock());
        // Cần logic lấy ImageUrl/CategoryName ở đây nếu muốn đầy đủ
        return dto;
    }
}