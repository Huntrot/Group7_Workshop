package org.example.flyora_backend.DTOs;

public record ChatBotDTO(
    Integer customerId,
    String message
) {}
