package org.example.flyora_backend.dynamo.models;

import org.example.flyora_backend.dynamo.SafeIntegerConverter;

import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.*;

@DynamoDbBean
@Setter
public class AccountDynamoDB {
    private Integer id;
    private String username;
    private String password;
    private String email;
    private String phone;
    private Boolean isActive;
    private Integer roleId;
    private Boolean isApproved;
    private Integer approvedBy;

    @DynamoDbPartitionKey
    @DynamoDbAttribute("id")
    @DynamoDbConvertedBy(SafeIntegerConverter.class)
    public Integer getId() {
        return id;
    }

    @DynamoDbAttribute("username")
    @DynamoDbSecondaryPartitionKey(indexNames = "username-index")
    public String getUsername() {
        return username;
    }

    @DynamoDbAttribute("password") public String getPassword() { return password; }
    @DynamoDbAttribute("email") public String getEmail() { return email; }
    @DynamoDbAttribute("phone") public String getPhone() { return phone; }
    @DynamoDbAttribute("is_active") public Boolean getIsActive() { return isActive; }
    @DynamoDbAttribute("role_id") public Integer getRoleId() { return roleId; }
    @DynamoDbAttribute("is_approved") public Boolean getIsApproved() { return isApproved; }
    @DynamoDbAttribute("approved_by") public Integer getApprovedBy() { return approvedBy; }
}