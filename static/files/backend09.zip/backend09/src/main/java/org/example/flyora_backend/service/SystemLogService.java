package org.example.flyora_backend.service;

// import java.util.List;
// import org.example.flyora_backend.DTOs.SystemLogDTO;

public interface SystemLogService {
    // void logAction(Integer adminId, String action);
    
    // List<SystemLogDTO> getAllSystemLogs();
}